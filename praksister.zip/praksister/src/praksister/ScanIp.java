/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praksister;

import java.net.InetAddress;

/**
 *
 * @author LENOVO
 */
public class ScanIp {
    public static void main(String[] args) throws Exception {
        try {
            //mengambil alamat host
            InetAddress localAddress = InetAddress.getLocalHost();
            //mengambil alamat address dengan format byte
            byte[] ip= localAddress.getAddress();
            for (int i = 0; i <254; i++) {
                //input data lengh ip
                ip[3]=(byte) i;
                InetAddress address = InetAddress.getByAddress(ip);         
                String a = address.getHostAddress();
                InetAddress[] ia = InetAddress.getAllByName(a);
                
                for (int j = 0; j < ia.length; j++) {
                    if (ia[j].isReachable(100)){
                        System.out.println(ia[j] +" is Rechable");
                    }else{
                        System.out.println(ia[j] +" unrecheble");
                    }  
                        
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
